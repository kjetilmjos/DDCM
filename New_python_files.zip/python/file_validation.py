#-*- coding: utf-8 -*-
from openpyxl import load_workbook
from dateutil.parser import parse
import datetime

pi_exportfile = 'Example_pi_export.xlsx' # name of the excel export file from pi

# Loads the selected export file
wb2 = load_workbook(pi_exportfile)
ws1 = wb2.active

# Maximum allowed columns
columns = ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK']

allowed_columns = len(columns)+2
errors = 0

# Counts the number of columns in pi file and checks in number of columns is too long
if ws1.max_column > allowed_columns:
    errors = 1
    print("Too many columns in use, is this only one month?")

# Checks the date cells for wrong date format
s = 0
while s <= ws1.max_column-4:
    try_date = ws1[columns[s]+ str(2)].value
    if isinstance(try_date,datetime.datetime) == False:
        errors = 1
        print("Date not valid")
    s += 1

# Prints error message to user if file not OK
if errors ==1:
    print("Input file not valid")
else:
    print("File OK")
